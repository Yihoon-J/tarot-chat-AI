from langchain_core.prompts.prompt import PromptTemplate

# For backwards compatibility.
Prompt = PromptTemplate

__all__ = ["PromptTemplate", "Prompt"]
