from langchain_core.prompts.few_shot_with_templates import FewShotPromptWithTemplates

__all__ = ["FewShotPromptWithTemplates"]
