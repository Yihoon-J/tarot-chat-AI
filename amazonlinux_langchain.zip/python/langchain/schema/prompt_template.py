from langchain_core.prompts import BasePromptTemplate, format_document

__all__ = ["BasePromptTemplate", "format_document"]
