from langchain_core.documents import BaseDocumentTransformer, Document

__all__ = ["Document", "BaseDocumentTransformer"]
