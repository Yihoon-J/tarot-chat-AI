from langchain_core.retrievers import BaseRetriever

__all__ = ["BaseRetriever"]
