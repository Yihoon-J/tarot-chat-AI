from langchain_core.embeddings import Embeddings

__all__ = ["Embeddings"]
